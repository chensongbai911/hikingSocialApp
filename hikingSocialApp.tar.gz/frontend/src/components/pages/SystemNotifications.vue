<template>
  <div class="min-h-screen bg-gray-50">
    <!-- 顶部导航栏 -->
    <div class="bg-white p-4 sticky top-0 z-10 border-b border-gray-100">
      <div class="flex items-center space-x-3">
        <button @click="router.back()" class="p-2 -ml-2">
          <svg class="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
          </svg>
        </button>
        <h1 class="text-xl font-bold text-gray-800">系统通知</h1>
      </div>
    </div>

    <!-- 通知列表 -->
    <div class="p-4 space-y-4">
      <div
        v-for="notification in notifications"
        :key="notification.id"
        class="bg-white rounded-2xl p-4 shadow-sm"
      >
        <div class="flex items-start space-x-4">
          <!-- 图标 -->
          <div :class="['w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0', getIconBgClass(notification.type)]">
            <svg v-if="notification.type === 'security'" class="w-6 h-6 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
            </svg>
            <svg v-else-if="notification.type === 'activity'" class="w-6 h-6 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"/>
            </svg>
            <svg v-else-if="notification.type === 'update'" class="w-6 h-6 text-teal-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14z"/>
              <path d="M12 6.5L7 12h4v5.5h2V12h4z"/>
            </svg>
            <svg v-else class="w-6 h-6 text-green-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
            </svg>
          </div>

          <!-- 内容 -->
          <div class="flex-1 min-w-0">
            <div class="flex items-start justify-between mb-2">
              <h3 class="font-medium text-gray-800">{{ notification.title }}</h3>
              <span class="text-sm text-gray-400 flex-shrink-0 ml-2">{{ notification.time }}</span>
            </div>
            <p class="text-sm text-gray-600 leading-relaxed" v-html="notification.content"></p>
          </div>
        </div>
      </div>

      <!-- 空状态 -->
      <div v-if="notifications.length === 0" class="py-20 text-center text-gray-400">
        <svg class="w-20 h-20 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
        </svg>
        <p>暂无系统通知</p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()

interface Notification {
  id: string
  type: 'security' | 'activity' | 'update' | 'safety'
  title: string
  content: string
  time: string
}

const notifications = ref<Notification[]>([
  {
    id: '1',
    type: 'security',
    title: '账号安全提醒',
    content: '您的账号于今日 10:28 在新设备上登录。<br/>若非本人操作，请及时修改密码。',
    time: '10:30'
  },
  {
    id: '2',
    type: 'activity',
    title: '官方活动邀请',
    content: '【周末香山徒步交友】活动即将截止报名！目前已有32位小伙伴加入，快来看看吧。',
    time: '昨天'
  },
  {
    id: '3',
    type: 'update',
    title: '功能更新公告',
    content: 'V2.4版本上线！新增"路线轨迹共享"功能，爬山安全更有保障。立即更新体验。',
    time: '周三'
  },
  {
    id: '4',
    type: 'safety',
    title: '户外安全指南',
    content: '秋季登山温差大，请携带足够的保暖衣物和补给品。愿你享受大自然的美好。',
    time: '10月24日'
  }
])

const getIconBgClass = (type: string) => {
  const classes = {
    security: 'bg-blue-50',
    activity: 'bg-orange-50',
    update: 'bg-teal-50',
    safety: 'bg-green-50'
  }
  return classes[type as keyof typeof classes] || 'bg-gray-50'
}
</script>
