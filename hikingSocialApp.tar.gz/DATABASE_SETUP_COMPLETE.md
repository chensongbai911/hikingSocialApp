# 🚀 快速开始指南 - 数据库初始化

**更新时间**: 2026-01-14
**状态**: ✅ 已完成

---

## 📋 已完成工作

### ✅ Task 1: 数据库字段规范统一

**输出文件**:

- `backend/src/database/FIELD_NAMING_GUIDE.md` - 字段命名规范文档

**完成内容**:

- ✅ 确认所有字段使用 snake_case 命名
- ✅ 确认所有外键使用{表名}\_id 格式
- ✅ 确认所有 URL 字段使用{对象}\_url 格式
- ✅ 确认所有布尔字段使用 is\_{状态}格式
- ✅ 确认所有时间字段规范（created_at, updated_at, deleted_at）
- ✅ 确认所有枚举类型规范
- ✅ 文档化所有字段命名规则

**结论**: 当前数据库结构完全符合规范，无需修改！

---

### ✅ Task 2: 创建测试数据 SQL 脚本

**输出文件**:

- `backend/src/database/seed_data.sql` - 测试数据脚本

**测试数据详情**:
| 数据类型 | 数量 | 说明 |
|---------|------|------|
| 用户 (users) | 10 | 不同性别、年龄、等级的测试用户 |
| 用户偏好 (user_preferences) | 40+ | 每个用户 5-8 个偏好标签 |
| 用户照片 (user_photos) | 20+ | 部分用户有 3-5 张相册照片 |
| 活动 (activities) | 15 | 覆盖 5 种状态的测试活动 |
| 参与记录 (participations) | 30+ | 包含 joined/completed/cancelled 状态 |

**测试账号**:

```
邮箱: zhangsan@test.com
密码: password123
昵称: 山间清风
```

**活动状态分布**:

- `approved` (已批准): 5 个活动
- `ongoing` (进行中): 2 个活动
- `pending` (待审核): 3 个活动
- `completed` (已完成): 3 个活动
- `cancelled` (已取消): 2 个活动

---

## 🎯 如何初始化数据库

### 方法 1: 使用批处理脚本 (推荐)

```bash
# Windows用户
.\init-database.bat

# 根据提示输入MySQL配置
# 用户名: root
# 主机: localhost
# 端口: 3306
# 密码: [你的MySQL密码]
```

### 方法 2: 手动执行 SQL

```bash
# 1. 登录MySQL
mysql -u root -p

# 2. 创建数据库
CREATE DATABASE IF NOT EXISTS hiking_app CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hiking_app;

# 3. 执行结构脚本
SOURCE backend/src/database/init.sql;

# 4. 导入测试数据
SOURCE backend/src/database/seed_data.sql;
```

### 方法 3: 使用 MySQL Workbench

1. 打开 MySQL Workbench
2. 连接到本地 MySQL 服务器
3. 点击 `File` → `Run SQL Script`
4. 依次执行:
   - `backend/src/database/init.sql`
   - `backend/src/database/seed_data.sql`

---

## 📊 数据验证

初始化完成后，运行以下 SQL 验证数据：

```sql
USE hiking_app;

-- 查看统计信息
SELECT '用户数量' as type, COUNT(*) as count FROM users
UNION ALL
SELECT '偏好数量', COUNT(*) FROM user_preferences
UNION ALL
SELECT '照片数量', COUNT(*) FROM user_photos
UNION ALL
SELECT '活动数量', COUNT(*) FROM activities
UNION ALL
SELECT '参与记录数量', COUNT(*) FROM participations;

-- 查看活动状态分布
SELECT status, COUNT(*) as count
FROM activities
GROUP BY status;

-- 查看活动参与人数
SELECT
  a.id,
  a.title,
  a.status,
  COUNT(p.id) as participant_count,
  a.max_participants
FROM activities a
LEFT JOIN participations p ON a.id = p.activity_id
GROUP BY a.id, a.title, a.status, a.max_participants
ORDER BY a.created_at DESC;
```

**预期结果**:

- 用户数量: 10
- 偏好数量: 40+
- 照片数量: 20+
- 活动数量: 15
- 参与记录数量: 30+

---

## 🧪 测试用户列表

| ID       | 邮箱                | 昵称         | 性别 | 年龄 | 等级 |
| -------- | ------------------- | ------------ | ---- | ---- | ---- |
| user-001 | zhangsan@test.com   | 山间清风     | 男   | 28   | 中级 |
| user-002 | lisi@test.com       | 徒步达人     | 女   | 25   | 高级 |
| user-003 | wangwu@test.com     | 户外小白     | 男   | 22   | 初级 |
| user-004 | zhaoliu@test.com    | 风景摄影师   | 女   | 30   | 中级 |
| user-005 | sunqi@test.com      | 周末探险家   | 男   | 32   | 中级 |
| user-006 | qianba@test.com     | 爱宠人士     | 女   | 27   | 初级 |
| user-007 | zhoujiu@test.com    | 长距离挑战者 | 男   | 35   | 高级 |
| user-008 | wushi@test.com      | 轻松休闲派   | 女   | 24   | 初级 |
| user-009 | zhengshiyi@test.com | 露营爱好者   | 男   | 29   | 高级 |
| user-010 | wangshier@test.com  | 社交达人     | 女   | 26   | 初级 |

**统一密码**: `password123`
**密码哈希**: `$2b$10$rZ9V8h6qNzK5YmD4xJ3yYOu8yqF3fX2wL1pQ5tR6vN7cM9eG4hK8m`

---

## 🎯 测试活动亮点

### 即将开始的活动

1. **螺髻山国家森林公园徒步** (act-001)

   - 状态: approved
   - 难度: moderate
   - 参与人数: 4/15

2. **香山红叶登山活动** (act-002)
   - 状态: approved
   - 难度: easy
   - 参与人数: 5/20

### 进行中的活动

1. **太行山大峡谷穿越** (act-006)

   - 状态: ongoing
   - 难度: hard
   - 参与人数: 2/10

2. **泰山日出登山** (act-007)
   - 状态: ongoing
   - 难度: moderate
   - 参与人数: 0/20

### 已完成的活动

1. **八达岭长城徒步** (act-011)
   - 状态: completed
   - 参与人数: 5 人
   - 平均评分: 4.8/5

---

## 📂 相关文件

```
backend/src/database/
├── init.sql                    # 数据库结构脚本 ✅
├── seed_data.sql              # 测试数据脚本 ✅
├── FIELD_NAMING_GUIDE.md      # 字段命名规范 ✅
└── create_users_and_fk.sql    # (旧文件，可删除)

项目根目录/
└── init-database.bat          # 数据库初始化脚本 ✅
```

---

## ⚠️ 注意事项

1. **密码哈希**: 测试数据中的密码哈希是用 bcrypt 生成的，实际使用时需要在后端用 bcrypt 验证
2. **清空数据**: seed_data.sql 会清空现有数据，生产环境慎用！
3. **外键约束**: 删除数据时注意外键约束关系
4. **软删除**: 所有表都有 deleted_at 字段支持软删除
5. **时区**: 确保 MySQL 时区设置正确（建议使用 UTC）

---

## 🔗 下一步

数据库初始化完成后，继续以下任务：

- [ ] **Task 3**: 定义统一 API 响应规范
- [ ] **Task 4**: 实现认证相关 API
- [ ] **Task 5**: 实现用户相关 API
- [ ] **Task 6**: 实现活动相关 API
- [ ] **Task 7**: 实现发现页面 API
- [ ] **Task 8**: 实现图片上传服务

参考文档: `FULLSTACK_INTEGRATION_PLAN.md`

---

**状态**: ✅ 数据库准备完成，可以开始 API 开发！
**下一步**: 定义统一的 API 响应规范
