UPDATE users SET password_hash = '$2a$10$QHAqiC9VFoEtX0mXRhbXPOz0VEZIoyhSV2J5pR3G3hOOnAx42.cPG';
