# 用户功能测试指南

## 问题修复

### 1. 偏好标签保存失败修复

**问题**: `preference_type` 字段数据被截断
**原因**: 数据库字段是 ENUM 类型，不支持 'hiking_preference' 值
**修复**: 将字段改为 VARCHAR(50)

**执行修复**:

```bash
# 在项目根目录运行
fix-preferences.bat
```

修复后，偏好标签将正常保存。

---

## 功能测试清单

### ✅ 1. 偏好标签功能

#### 测试步骤：

1. 访问 http://localhost:5173/edit-profile
2. 在"徒步偏好"区域添加标签：
   - 点击推荐标签（如"周末出发"）
   - 或自定义输入标签
3. 点击"保存"按钮
4. 返回个人主页 http://localhost:5173/profile
5. 验证"我的徒步偏好"区域显示已保存的标签

#### 预期结果：

- ✅ 标签成功保存
- ✅ 个人主页正确显示标签
- ✅ 再次编辑时能加载已有标签

---

### 🚧 2. 头像上传功能

#### 当前状态：

- ✅ 前端 UI 完成（点击头像触发选择）
- ✅ 前端预览功能完成（选择后立即预览）
- ⚠️ 后端接口存在但未完全集成
- ❌ 实际上传到服务器功能待完善

#### 测试步骤：

1. 访问 http://localhost:5173/edit-profile
2. 点击头像区域
3. 选择图片（支持拍照或从相册选择）
4. 查看预览效果
5. 点击"保存"

#### 当前行为：

- 图片会在编辑页面预览
- 保存时会将 URL 保存到 `avatar_url` 字段
- 但图片是 base64 格式，较大，实际应上传到服务器获取 URL

#### 需要完善：

```javascript
// EditProfile.vue 中需要添加实际上传逻辑
const uploadAvatar = async () => {
  // 1. 选择文件
  // 2. 上传到服务器 POST /api/v1/users/avatar
  // 3. 获取返回的 URL
  // 4. 更新 formData.avatar_url
}
```

---

### 🚧 3. 生活相册功能

#### 当前状态：

- ✅ 后端接口完整：
  - POST /api/v1/users/photos - 添加照片
  - DELETE /api/v1/users/photos/:photoId - 删除照片
  - GET /api/v1/users/profile - 获取相册（包含在用户资料中）
- ✅ 前端显示逻辑完成
- ⚠️ 前端上传功能部分实现
- ❌ 删除功能未实现

#### 测试步骤：

1. 访问 http://localhost:5173/profile
2. 点击"添加照片"按钮
3. 选择一张或多张图片
4. 验证照片是否显示在相册中

#### 当前行为：

- 点击"添加照片"可以选择文件
- 但实际上传逻辑被注释了（TODO 标记）
- 需要实现实际的文件上传

#### 需要完善：

```javascript
// Profile.vue 中需要取消注释并完善上传逻辑
const addPhoto = async () => {
  // 1. 选择文件（已实现）
  // 2. 上传到服务器 POST /api/v1/users/photos（需要实现）
  // 3. 刷新用户资料显示新照片（需要实现）
}
```

---

## API 端点说明

### 用户资料相关

**获取用户资料**:

```
GET /api/v1/users/profile
Authorization: Bearer <token>

Response: {
  code: 200,
  data: {
    id: "user-011",
    nickname: "陈松柏",
    avatar_url: "...",
    preferences: [
      { id: "pref-001", preference_type: "hiking_preference", preference_value: "周末出发" }
    ],
    photos: [
      { id: "photo-001", photo_url: "..." }
    ]
  }
}
```

**更新用户资料**:

```
PUT /api/v1/users/profile
Authorization: Bearer <token>
Content-Type: application/json

Body: {
  "nickname": "新昵称",
  "gender": "female",
  "age": 25,
  "bio": "个人简介",
  "avatar_url": "https://..."
}
```

**更新用户偏好**:

```
PUT /api/v1/users/preferences
Authorization: Bearer <token>
Content-Type: application/json

Body: {
  "preferences": [
    { "type": "hiking_preference", "value": "周末出发" },
    { "type": "hiking_preference", "value": "5-10km" }
  ]
}
```

**更新头像**:

```
POST /api/v1/users/avatar
Authorization: Bearer <token>
Content-Type: multipart/form-data

Body: FormData with 'avatar' field containing image file
```

**添加照片**:

```
POST /api/v1/users/photos
Authorization: Bearer <token>
Content-Type: multipart/form-data

Body: FormData with 'photo' field containing image file
```

**删除照片**:

```
DELETE /api/v1/users/photos/:photoId
Authorization: Bearer <token>
```

---

## 待完善功能优先级

### 高优先级 🔴

1. **完善头像上传功能**

   - 实现真实文件上传到服务器
   - 处理上传进度提示
   - 错误处理

2. **完善相册上传功能**
   - 实现真实文件上传
   - 实现照片删除功能
   - 实现照片排序功能

### 中优先级 🟡

3. **图片压缩和优化**

   - 上传前压缩图片
   - 生成缩略图
   - 限制文件大小

4. **用户体验优化**
   - 添加上传进度条
   - 添加图片预览
   - 添加加载状态

### 低优先级 🟢

5. **相册管理**
   - 批量删除
   - 照片编辑（裁剪、滤镜）
   - 照片分享

---

## 测试数据

### 测试用户

- Email: user1@test.com
- Password: password123
- User ID: user-011

### 偏好标签示例

- 周末出发
- 高海拔
- 5-10km
- 摄影爱好者
- 露营

---

## 常见问题

### Q: 偏好标签保存失败？

A: 确保已执行数据库修复脚本 `fix-preferences.bat`

### Q: 头像显示不出来？

A: 当前使用 base64 预览，实际需要上传到服务器获取 URL

### Q: 相册照片显示不出来？

A: 检查后端是否正确返回 photos 数组，URL 是否有效

### Q: 如何测试文件上传？

A: 需要先完善上传逻辑，将注释的 TODO 部分实现
